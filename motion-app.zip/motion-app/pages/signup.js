import Signup from "../components/Signup.jsx";

const Form = () => {
    return(
        <div>
            <Signup/>
        </div>
    );
};

export default Form;   